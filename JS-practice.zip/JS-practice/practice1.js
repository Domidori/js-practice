'use strict';

/*makeArmy
function makeArmy() {

  let shooters = [];

  for (let i = 0; i < 10; i++) {
    shooters.push(function() {
      alert( i ); // выводит свой номер
    });
  }

  return shooters;
}

var army = makeArmy();

army[0](); // 0
army[5](); // 5
*/

/*functions
function showName(name, surname) {
    var fullname = name + ' ' + surname;
    return fullname;
}

var dmitryName = "Dmitry";
var dmitrySurname = "Monin";
var dmitryFullName = showName(dmitryName, dmitrySurname);
console.log(dmitryFullName);
*/

/*while, do-while, for
var i = 2;

while (i < 9) {
    document.write('Все еще меньше 9')
     i++
}

var i = 0;
do {
    alert(i);
    i++
} while (i < 5);

for (var i = 1; i < 5; i++) {
    document.write('Все еще меньше 5')
}
*/

/*Array
// let someArr = ["Ivan", 'dmitry', 'gfdfs'];
//     document.write(someArr[2]);
// someArr[2] = 'Mike';
//     document.write(someArr[2
*/

/*Objects
let orc = {
    color: 'green',
    height: 210,
    weight: 150,
    attack: function() {
        document.write('WAAAAHG!!!');
    }
}

 console.log(orc.weight);
 orc.attack()

 orc.weight = 200;
 console.log(orc.weight);
 */

/*function ageChecker
function ageChecker(age) {
    return (age > 18) || confirm('Родители разрешили?');

    if (age > 18) {
        return true;
    } else {
        return confirm('Родители разрешили?')
    }
}

var age = prompt('Ваш возраст?');

if (ageChecker(age)) {
    alert( 'Доступ разрешен' );
} else {
    alert( 'В доступе отказано' );
}
*/

/* Practice
function minNum(a, b) {
    if (a < b) {
        return a;
    } else {
        return b;
    }
}

function minNum(a, b) {
    return (a < b) ? a : b;
}

console.log(minNum(8, 7));

for (var i = 0; i < 3; i++) {
  alert( "номер " + i + "!" );
}

var i = 0;
while (i < 3) {
    alert('номер' + i + '!')
    i++
}

var num = 0;
while (true) {
    var userTry = +prompt('Введите число: ')

    if (userTry > 100) {
        break;
    }
}

var num;

do {
  num = prompt("Введите число больше 100?", 0);
} while (num <= 100 && num != null);


for (var i = 0; i <= 10; i++) {
    if (i % 2 == 0) {
    alert( i );
  }
}

var a = 5 * 4;
switch (a) {
    case 20:
        alert('low');
        break;
    case 25:
        alert('You got it!');
        break;
    case 30:
    alert('That`s too many!');
        break;
    default:
    alert('wtf!')
}
*/


// ES5
/*Деструктуризация массивов
let [firstName, secondName] = ['Dmitry', 'Vlas'];
console.log(firstName);

let[, thirdName, ...rest] = "Юлий Цезарь Император Рима".split(" ");
console.log(thirdName);
console.log(rest);
*/

// значения по умолчанию
// let [firstName="Гость", lastName="Анонимный"] = [];
//
// alert(firstName); // Гость
// alert(lastName);  // Анонимный
//
//
// //Деструктуризация объекта
// let options = {
//     color: 'blue',
//     height: 100,
// };
//
// let {color:c, width:w = 210, height} = options;
//
// alert(c);
// alert(w);
//
//
// let options = {
//   size: {
//       width: 180,
//       height:100
//   },
//   items: ["Пончик", "Пирожное"]
// }
//
// let { title="Menu", size: {width, height}, items: [item1, item2] } = options;
//
// alert(title);
// alert(item2);
//
// function showMenu(title = "...", width = 180, height = 100) {
//     alert('title= ' + title + ' ' + 'width= ' + width + ' ' + 'height= ' + height);
// }
//
// showMenu(undefined, null, undefined);
//
// function sayHi(who = getCurrentUser().toUpperCase()) {
//     alert('Hi!, ' + who);
// }
//
// function getCurrentUser() {
//     return 'Dmitry';
// }
// sayHi();


// function showName(firstName, lastName, ...rest) {
//     alert(firstName + ' ' + lastName + ' - ' + rest);
// }
// showName("Юлий", "Цезарь", "Император", "Рима");
//
// let numbers = [2, 43, 54, 423, 425, 65];
// let max = Math.max(...numbers);
// alert(max);
//
// function m() {};
//
// let g = function g() {};
//
// alert(m.name + ' ' + g.name);
//
// let inc = function(x) { return x + 1; };
// alert(inc(3));
//
//
// let sum = (a,b) => a + b;
// alert(sum(32,543));
//
// let arr = [5, 8, 3];
// let sorted = arr.sort((a,b) => a - b );
// alert(sorted);


Строки
let apples = 2;
let oranges = 3;
alert(`${apples} + ${oranges} = ${apples + oranges}`);
//
// const message = `This equals to ${100/4}`;
// console.log(message);

const tag = (strings, ...values) => {
    console.log(strings, values);
    if (values[0] < 20) {
        values[1] = 'awake';
    }
    return `${strings[0]}${values[0]}${strings[1]}${values[1]}`
}
    const date = `Its ${new Date().getHours()} and Im ${'sleepy'}`

    console.log(date);


let name = "Вася";
let isAdmin = true;
let user = {
  name,
  isAdmin
};
alert( JSON.stringify(user) ); // {"name": "Вася", "isAdmin": true}
*/


$(document).ready(function(){
    $("button").click(function(){
        $("p").hide();
    });
});
