'use strict';

// var age = prompt('how old`re you?')
//
//     var sayHi = (age >= 18) ?
//     function(){ alert('Come in, please!'); } : function(){ alert('Access closed!'); };
//
//     sayHi();
//
//     var steamGuard = prompt('Your code, please')
//
//     var steamAnswer = (steamGuard >= 30) ?
//     function(){ alert("Access granted!") } : function(){ alert("Wrong code!") };
//
//     steamAnswer();


function ask(question, yes, no) {
    if (confirm(question)) yes()
    else no();
    }

ask(
    "You agree?",
    function(){ alert("You said 'YES!'"); },
    function(){ alert("You said 'NO!'"); }
)


var sum = new Function('a, b, c' , 'return a + (b / c)');
var result = sum(5, 14, 2);
console.log(result);
